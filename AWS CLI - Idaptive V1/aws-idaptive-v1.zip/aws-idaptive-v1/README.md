Please see https://developer.centrify.com/v1.2/docs/aws-cli
